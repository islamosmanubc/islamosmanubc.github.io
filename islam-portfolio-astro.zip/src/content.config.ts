import { defineCollection, z } from "astro:content";

const projects = defineCollection({
  type: "content",
  schema: z.object({
    title: z.string(),
    slug: z.string(),
    year: z.number(),
    period: z.string(),
    subtitle: z.string(),
    summary: z.string(),
    featured: z.boolean().default(false),
    tags: z.array(z.string()),
    stack: z.array(z.string()),
    impact: z.string(),
    cover: z.string(),
    github: z.string().url().optional(),
    demo: z.string().url().optional(),
    paper: z.string().url().optional(),
    order: z.number()
  })
});

const publications = defineCollection({
  type: "content",
  schema: z.object({
    title: z.string(),
    year: z.number(),
    venue: z.string(),
    authors: z.string(),
    category: z.enum(["Journal", "Conference", "Accepted", "Submitted"]),
    featured: z.boolean().default(false),
    tags: z.array(z.string()).default([]),
    links: z
      .object({
        paper: z.string().url().optional(),
        scholar: z.string().url().optional()
      })
      .optional(),
    order: z.number()
  })
});

export const collections = {
  projects,
  publications
};
