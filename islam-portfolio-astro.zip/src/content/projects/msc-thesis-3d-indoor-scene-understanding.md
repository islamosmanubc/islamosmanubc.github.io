---
title: "MSc Thesis: 3D Indoor Scene Understanding in Image Sequence"
slug: "msc-thesis-3d-indoor-scene-understanding"
year: 2018
period: "2015 – 2018"
subtitle: "RGB-D scene understanding through detection, tracking, and segmentation."
summary: "Graduate research on structured indoor-scene interpretation using RGB-D sequences and classical-plus-deep computer vision methods."
featured: false
tags: ["MSc", "RGB-D", "Scene Understanding", "Computer Vision"]
stack: ["Object Detection", "Tracking", "Segmentation", "RGB-D Vision"]
impact: "Established a foundational research base in visual scene understanding that later evolved into work on video understanding and segmentation."
cover: "/images/projects/msc-thesis-3d-indoor-scene-understanding.svg"
order: 7
---

## Problem

Indoor scene understanding requires reasoning about objects, geometry, and temporal consistency across image sequences. RGB-D data adds structure, but also introduces its own modeling and data challenges.

## Focus

My MSc work explored object detection, tracking, and segmentation methods for understanding indoor scenes from image sequences, with an emphasis on structured interpretation rather than single-frame classification.

## Lasting impact

This work became the foundation for later research in segmentation, domain generalization, and multimodal scene understanding.
