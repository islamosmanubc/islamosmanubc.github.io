---
title: "Video Annotation Tool"
slug: "video-annotation-tool"
year: 2024
period: "2024"
subtitle: "A lightweight desktop interface for interval-based scenario labeling."
summary: "An annotation interface for turning driving videos into structured event intervals with a faster, safer workflow."
featured: true
tags: ["Annotation", "Desktop Tool", "Data Labeling", "Autonomous Driving"]
stack: ["Python", "Tkinter", "Excel I/O", "Video UX"]
impact: "Accelerated scenario-label creation and improved annotation reliability through task-specific workflow features."
cover: "/images/projects/video-annotation-tool.svg"
order: 4
---

## Problem

High-quality scenario labels are essential, but off-the-shelf annotation tools often do not match the exact event-interval workflow needed for driving datasets.

## What I built

I created a Tkinter-based annotation tool that lets users annotate event intervals as `(video, start, end, event)` records and persist them directly to spreadsheet outputs.

## Workflow features

- folder navigation,
- timeline scrubbing,
- event selection from a shared label list,
- warnings for already-annotated videos,
- immediate persistence to Excel,
- per-video annotation lists,
- checkpointing and keyboard shortcuts.

## Outcome

This tool reduced friction in the human-labeling loop and served as a practical bridge between raw video collections and higher-quality training or evaluation data.
