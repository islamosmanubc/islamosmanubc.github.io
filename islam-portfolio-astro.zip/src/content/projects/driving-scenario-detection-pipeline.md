---
title: "Driving Scenario Detection Pipeline"
slug: "driving-scenario-detection"
year: 2024
period: "2024"
subtitle: "An interpretable end-to-end pipeline for front-camera traffic-event detection."
summary: "A scenario-detection system that fuses multiple perception signals with temporal reasoning to detect meaningful driving events."
featured: true
tags: ["Scenario Detection", "Computer Vision", "Tracking", "Temporal Reasoning"]
stack: ["Python", "Deep Learning", "FSMs", "Multi-object Tracking"]
impact: "Produced interpretable event windows and confidence scores from complex perception inputs, enabling downstream labeling and model-development workflows."
cover: "/images/projects/driving-scenario-detection.svg"
order: 3
---

## Problem

Scenario understanding in driving videos often needs more than a single detector. Useful traffic events emerge from temporal behavior, lane structure, motion cues, and multi-object interactions.

## What I built

I built an end-to-end pipeline that fuses lane marks, object detections, lane semantics, depth, and optical flow. On top of these signals, I implemented finite-state-machine reasoning and multi-object tracking to convert frame-level perception into event-level predictions.

## Outputs

The pipeline produces:

- event windows,
- scenario bitmasks,
- weighted confidence scores,
- optional visualization outputs,
- and video-writing support for debugging or review.

## Design value

A major benefit of this system is interpretability. Instead of returning only a black-box label, it encodes structured temporal logic that makes the output easier to inspect, validate, and improve.
