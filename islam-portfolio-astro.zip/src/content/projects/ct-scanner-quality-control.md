---
title: "CT Scanner Quality Control"
slug: "ct-scanner-quality-control"
year: 2023
period: "2023"
subtitle: "Self-supervised vision transformers for scanner calibration quality assessment."
summary: "A medical-imaging QC system that uses self-supervised pretraining and vision transformers to improve generalization in scanner calibration assessment."
featured: true
tags: ["Medical Imaging", "Vision Transformers", "Self-supervised Learning", "Quality Control"]
stack: ["Vision Transformers", "Self-supervised Learning", "Medical Imaging"]
impact: "Delivered a 12% improvement over standard baselines and supported publication and intellectual-property outcomes."
cover: "/images/projects/ct-scanner-quality-control.svg"
order: 5
---

## Problem

Quality control for medical scanners is important, but labeled data can be limited and domain shift is a persistent challenge across equipment and acquisition conditions.

## What I built

I curated relevant medical-imaging data and used self-supervised pretraining with a vision transformer backbone to improve domain generalization for CT scanner calibration assessment.

## Research contribution

The project focused on combining strong visual representation learning with a practical quality-control task. The resulting model improved performance by 12% over standard baselines and supported abstracts and a paper.

## Why it stands out

This work combines applied medical AI, representation learning, and real deployment relevance. It also informed later patent-oriented thinking around automated scanner QC workflows.
