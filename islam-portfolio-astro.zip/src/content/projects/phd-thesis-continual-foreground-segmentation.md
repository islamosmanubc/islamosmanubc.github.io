---
title: "PhD Thesis: Continual Foreground Segmentation with Limited Data"
slug: "phd-thesis-continual-foreground-segmentation"
year: 2023
period: "2019 – 2023"
subtitle: "Continual and data-efficient vision research for robust foreground segmentation."
summary: "A long-term research program on foreground segmentation under limited-data settings, emphasizing continual adaptation and generalization."
featured: true
tags: ["PhD", "Continual Learning", "Segmentation", "Few-shot Learning"]
stack: ["Computer Vision", "Continual Learning", "Transformers", "Research"]
impact: "Produced multiple peer-reviewed outputs and a coherent research direction around adaptation, catastrophic forgetting, and data efficiency."
cover: "/images/projects/phd-thesis-continual-foreground-segmentation.svg"
order: 6
---

## Research focus

My PhD centered on a difficult question: how do we build foreground-segmentation systems that remain robust when labeled data is scarce and conditions change over time?

## Themes explored

The thesis explored continual and lifelong learning, limited-data adaptation, few-shot learning, and robust segmentation under distribution shift. This included methods designed to preserve prior knowledge while still adapting to new scenes or domains.

## Outcomes

The work led to peer-reviewed papers, conference presentations, and a broader research identity around practical robustness in vision systems.

## Why it matters

This research program shaped the way I think about AI systems more broadly: strong performance is not enough unless the model can adapt, retain useful knowledge, and stay dependable under real-world change.
