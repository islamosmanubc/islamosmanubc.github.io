---
title: "Video Retrieval App"
slug: "video-retrieval-app"
year: 2025
period: "2025"
subtitle: "Multimodal search over driving-video archives using text, tags, and reference clips."
summary: "A semantic retrieval interface that helps engineers find relevant driving footage quickly using text, metadata, and reference-video workflows."
featured: true
tags: ["Retrieval", "Multimodal Search", "Autonomous Driving", "Archive Search"]
stack: ["Sentence Transformers", "LLM", "Postgres", "AWS S3"]
impact: "Made large video collections far easier to explore by combining embedding similarity, structured metadata, and a practical desktop workflow."
cover: "/images/projects/video-retrieval-app.svg"
order: 2
---

## Problem

As driving datasets grow, it becomes increasingly difficult for engineers to locate the exact footage they need for error analysis, annotation, or model evaluation. Traditional filename search is not enough.

## What I built

I developed a GUI-based retrieval system that supports three entry points:

- natural-language text queries,
- comma-separated tag queries,
- and a local reference video for similarity search.

The retrieval logic combines sentence-transformer embeddings with weighted tag similarity. I also added an optional Gemini-assisted step for extracting tags from free-text user input.

## Product-facing details

To make the system more useful than a research prototype, I enriched search results with Postgres metadata and telemetry, added a built-in video player, clickable timestamped tags, a details dialog, and lazy-loaded side-camera videos from S3.

## Outcome

The result is a more efficient way to surface relevant footage in large archives, enabling faster triage, debugging, and dataset curation for autonomous-driving workflows.
