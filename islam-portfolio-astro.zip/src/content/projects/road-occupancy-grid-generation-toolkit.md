---
title: "Road Occupancy-Grid Generation Toolkit"
slug: "occupancy-grid-toolkit"
year: 2026
period: "2026 – Present"
subtitle: "Production-oriented tooling for structured bird’s-eye road-scene generation and editing."
summary: "A GUI-driven toolkit for generating, inspecting, and editing road occupancy-grid outputs from driving perception results and telemetry."
featured: true
tags: ["Autonomous Driving", "Tooling", "Occupancy Grid", "Perception"]
stack: ["Python", "GUI", "Telemetry", "Computer Vision"]
impact: "Turned raw perception and telemetry outputs into editable structured scene representations that support downstream analysis and labeling workflows."
cover: "/images/projects/occupancy-grid-toolkit.svg"
order: 1
---

## Problem

Driving perception teams often need a structured bird’s-eye representation of the scene, but the raw outputs come from several sources at once: lanes, masks, depth estimates, tracking results, and telemetry. Without a usable tooling layer, inspecting or correcting those outputs becomes slow and error-prone.

## What I built

I built a toolkit for generating and editing road occupancy-grid outputs, with a strong focus on usability for engineers and annotators. The interface supports pipeline controls such as run, pause, resume, and stop, and includes a large-scale JSON visualizer and editor for inspecting generated outputs.

## Core capabilities

- ROADSv2 occupancy-grid generation from lanes, masks, depth, and tracking.
- Post-processing utilities for propagation and refinement.
- Object-level editing, segment merge/split, and save-back workflows for corrected JSON.
- Auxiliary utilities such as relative-speed labeling and lane counting from bird’s-eye imagery.

## Why it matters

This project sits at the boundary between research infrastructure and product tooling. It helps transform raw perception outputs into operational artifacts that can be debugged, refined, and reused in later stages of the autonomous-driving pipeline.
