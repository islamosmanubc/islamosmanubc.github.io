export const profile = {
  name: "Islam Osman, PhD",
  title: "AI Researcher & Machine Learning Engineer",
  location: "Kelowna, British Columbia, Canada",
  email: "islam.osman.ai@gmail.com",
  github: "https://github.com/islamosmanubc",
  scholar: "https://scholar.google.com/citations?hl=en&user=placeholder",
  summary:
    "AI researcher and engineer building robust computer vision and multimodal systems for autonomous driving, medical imaging, and real-world AI products."
};

export const focusAreas = [
  "Computer Vision",
  "Vision-Language Models",
  "Continual / Lifelong Learning",
  "Few-Shot Learning",
  "Self-Supervised Learning",
  "Autonomous Driving",
  "Medical Imaging",
  "Applied AI Systems"
];

export const stats = [
  { label: "Peer-reviewed papers", value: "25+" },
  { label: "Years in AI research & engineering", value: "4+" },
  { label: "Graduate researchers mentored", value: "9" },
  { label: "Teaching & academic service", value: "10+ yrs" }
];

export const navLinks = [
  { label: "Home", href: "" },
  { label: "About", href: "about/" },
  { label: "Projects", href: "projects/" },
  { label: "Publications", href: "publications/" },
  { label: "Experience", href: "experience/" },
  { label: "Contact", href: "contact/" }
];

export const aboutParagraphs = [
  "I am an AI developer and researcher with a PhD in Computer Science from the University of British Columbia. My work sits at the intersection of computer vision, multimodal learning, and deployable machine learning systems.",
  "Across research and industry collaborations, I have built methods and tools for autonomous driving, medical imaging quality control, video understanding, and retrieval systems. My research background includes continual learning, few-shot learning, self-supervised learning, transformer-based vision models, and vision-language systems.",
  "I enjoy operating across the full stack of applied AI: framing the problem, building the model or pipeline, validating it experimentally, packaging it into usable tooling, and mentoring others who are contributing to the work."
];

export const experience = [
  {
    role: "Machine Learning Engineer (Scenario Detection)",
    organization: "Matt3r.AI",
    location: "Kelowna, BC",
    period: "2024 – Present",
    bullets: [
      "Built scenario detection tooling and data pipelines for driving video understanding.",
      "Developed automated labeling and retrieval workflows across large driving-video archives.",
      "Implemented occupancy-grid generation and auxiliary telemetry-aware utilities for downstream modeling."
    ]
  },
  {
    role: "Postdoctoral Fellow",
    organization: "University of British Columbia Okanagan",
    location: "Kelowna, BC",
    period: "May 2023 – Present",
    bullets: [
      "Co-authored peer-reviewed research in computer vision and medical imaging.",
      "Led a research team of graduate students and supported NSERC and Mitacs proposals.",
      "Designed and taught graduate-level Advanced Algorithms."
    ]
  },
  {
    role: "AI Researcher (CT Quality Control)",
    organization: "Interior Health / University of British Columbia",
    location: "Kelowna, BC",
    period: "2023",
    bullets: [
      "Curated CT data and built a quality-control model for scanner calibration assessment.",
      "Used self-supervised pretraining to improve medical-imaging domain generalization.",
      "Contributed to publications and patent-related work around scanner QC automation."
    ]
  },
  {
    role: "Data Scientist Intern (Credit Risk Analytics)",
    organization: "Scotiabank",
    location: "Kelowna, BC",
    period: "2022",
    bullets: [
      "Developed deep-learning imputation models for sparse credit data.",
      "Contributed to risk prediction workflows across diverse industry portfolios."
    ]
  },
  {
    role: "Machine Learning Engineer (Video Surveillance)",
    organization: "Irwin’s Safety & Industrial Labor Services",
    location: "Kelowna, BC",
    period: "2021",
    bullets: [
      "Built human-detection and confined-space monitoring tools for industrial analytics.",
      "Developed entry/exit analytics and workflow-specific monitoring components."
    ]
  }
];

export const education = [
  {
    degree: "PhD in Computer Science",
    school: "University of British Columbia",
    period: "2023",
    detail: "Dissertation: Continual Foreground Segmentation with Limited Data."
  },
  {
    degree: "MSc in Computer Science",
    school: "Ain Shams University",
    period: "2018",
    detail: "Thesis: Developing a method for 3D indoor scene understanding in image sequence."
  },
  {
    degree: "BSc in Computer Science",
    school: "Ain Shams University",
    period: "2013",
    detail: "Graduated with honors and ranked #2 in class."
  }
];

export const skillGroups = [
  {
    title: "Languages",
    items: ["Python", "C++", "C#", "Java", "TypeScript", "SQL"]
  },
  {
    title: "ML / DL",
    items: [
      "PyTorch",
      "TensorFlow",
      "Scikit-learn",
      "Transformers",
      "Vision Transformers",
      "LLMs",
      "VLMs"
    ]
  },
  {
    title: "Computer Vision",
    items: [
      "Detection",
      "Segmentation",
      "Tracking",
      "Depth Estimation",
      "Video Understanding",
      "Few-shot Learning",
      "Domain Generalization"
    ]
  },
  {
    title: "Graphics & HPC",
    items: ["OpenGL", "WebGL", "GLSL", "Unity3D", "CUDA", "OpenMP", "MPI"]
  },
  {
    title: "Production / Tooling",
    items: ["GitHub Actions", "Docker", "MLflow", "W&B", "pytest", "pre-commit", "Hydra"]
  }
];

export const awards = [
  "Graduate Student Award — University of British Columbia (2022)",
  "Student of the Year Excellence Award — University of British Columbia (2021)",
  "Best Teaching Assistant Award — Ain Shams University (received 3 times)"
];

export const service = [
  "Reviewer: IEEE TAI, IJCV, Journal of Signal, Image and Video Processing",
  "Reviewer: CVPR, ECCV, NeurIPS",
  "Conference chair roles across ICIP 2024, CCECE 2025, and RT-GNNs 2025"
];

export const contacts = [
  {
    label: "Email",
    value: "islam.osman.ai@gmail.com",
    href: "mailto:islam.osman.ai@gmail.com"
  },
  {
    label: "GitHub",
    value: "github.com/islamosmanubc",
    href: "https://github.com/islamosmanubc"
  },
  {
    label: "Google Scholar",
    value: "Scholar profile placeholder",
    href: "https://scholar.google.com/citations?hl=en&user=placeholder"
  }
];
