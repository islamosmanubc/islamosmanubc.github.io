# Islam Osman Portfolio — Astro Starter

A dark, project-first portfolio website for **Islam Osman, PhD**, designed for **Astro + GitHub Pages** and inspired by:

- **Visual direction:** `codewithsadee/vcard-personal-portfolio`
- **Information architecture:** `HugoBlox/hugo-theme-academic-cv`

## What is included

- Dark, card-based personal portfolio layout
- Project-first homepage and dedicated project detail pages
- Publications page with grouped entries
- Experience, education, and contact pages
- Content collections for projects and publications
- GitHub Pages workflow
- `AGENTS.md`, `AGENT.md`, and `PLAN.md` for Codex handoff

## Quick start

```bash
npm install
npm run dev
```

Open the local site at the URL Astro prints in the terminal.

## Build

```bash
npm run build
npm run preview
```

## GitHub Pages deployment

1. Push this project to GitHub.
2. In **Settings → Pages**, choose **GitHub Actions** as the source.
3. Run `npm install` once locally and commit the generated lockfile.
4. Push to `main`.

The included workflow is configured for GitHub Pages and uses `withastro/action`.

## Content editing

### Projects

Edit or add files in:

```text
src/content/projects/
```

Each project supports:

- title
- slug
- year
- period
- subtitle
- summary
- featured
- tags
- stack
- impact
- cover
- github/demo/paper
- order

### Publications

Edit or add files in:

```text
src/content/publications/
```

## Resume PDF

The current CV is stored at:

```text
public/resume/Islam_Osman_CV.pdf
```

Replace that file whenever a new version is ready.

## Notes for future refinement

- Replace placeholder Google Scholar link with the real profile URL
- Add real project screenshots or videos
- Add optional theme toggle if desired
- Add a custom domain by updating `site` and, if needed, `public/CNAME`
