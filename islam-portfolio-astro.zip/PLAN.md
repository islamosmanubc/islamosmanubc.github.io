# PLAN.md

## Goal

Turn this repository into a polished, dark-mode portfolio website for **Islam Osman, PhD** that showcases projects first, while still presenting publications, experience, education, and CV material in a clean academic-professional structure.

## Product direction

### Primary design reference
Use the visual feel of **codewithsadee/vcard-personal-portfolio**:
- dark theme by default
- premium cards
- clean sidebar/profile presence
- strong typography
- subtle hover motion
- compact, elegant information density

### Secondary structural reference
Borrow the content organization mindset of **HugoBlox Academic CV**:
- publications grouped for readability
- strong academic credibility
- clear separation of projects, experience, education, and CV materials

## Non-goals

- Do not turn the site into a generic blog.
- Do not make the homepage a dense PDF-style resume dump.
- Do not add unnecessary client-side frameworks or complex backend code.
- Do not add a contact form that requires server-side hosting unless explicitly requested.

## Implementation phases

### Phase 1 — Foundation
- [x] Set up Astro project structure
- [x] Add global styles and dark visual system
- [x] Add reusable layout and navigation
- [x] Add GitHub Pages workflow
- [x] Add Codex guidance files

### Phase 2 — Content model
- [x] Add content collections for projects
- [x] Add content collections for publications
- [x] Add site-wide structured data for profile, skills, experience, and education
- [x] Add current CV PDF to public assets

### Phase 3 — Main pages
- [x] Home page with hero, featured projects, selected publications, and experience preview
- [x] About page
- [x] Projects landing page
- [x] Project detail route
- [x] Publications page
- [x] Experience page
- [x] Contact page

### Phase 4 — Refinement
- [ ] Replace placeholder Google Scholar URL
- [ ] Replace SVG placeholders with real project visuals
- [ ] Tune copy and project narratives for public-facing polish
- [ ] Optionally add subtle section transitions or a tasteful theme toggle
- [ ] Add metadata improvements such as Open Graph images

## Acceptance criteria

The project is done when:

1. The site builds successfully with Astro.
2. The design clearly resembles a dark, refined vCard-style portfolio rather than a plain CV page.
3. Projects are the most visually important content on the site.
4. Publications, experience, and education remain present but secondary to projects.
5. All pages are usable on mobile and desktop.
6. GitHub Pages deployment works from the included workflow after dependencies are installed and a lockfile is committed.

## Content priorities

1. Projects
2. Research/publication credibility
3. Professional story and expertise
4. Experience timeline
5. Education and awards

## Future extensions

- Add a dedicated publications data import path from BibTeX
- Add project galleries or embedded videos
- Add writing / notes page only if it supports the personal brand
- Add case-study style long-form pages for the strongest 3–4 projects

## Working rule for coding agents

For any non-trivial change:
1. Read `AGENTS.md` first.
2. Update this plan if scope changes materially.
3. Implement in small, verifiable steps.
4. Keep the website project-first and dark-theme-first.
